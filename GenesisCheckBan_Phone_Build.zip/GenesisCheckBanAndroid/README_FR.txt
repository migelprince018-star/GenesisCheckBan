GENESIS CHECK BAN — PROJET ANDROID
==================================

Ce dossier contient le code source d'une application Android native.
Il ne contient PAS encore un fichier APK compilé.

POUR CONSTRUIRE L'APK :
1. Sur un ordinateur, installe Android Studio.
2. Ouvre le dossier GenesisCheckBan dans Android Studio.
3. Accepte la synchronisation Gradle et installe Android SDK Platform 35 si demandé.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio produira l'APK dans app/build/outputs/apk/debug/app-debug.apk.

FONCTIONS :
- Interface sombre avec accents dorés.
- Enregistrement et mise à jour de numéros.
- Recherche et historique locaux.
- Base SQLite intégrée.

IMPORTANT :
L'application ne se connecte pas à WhatsApp et ne peut pas vérifier les bannissements.
Les statuts ACTIF/BANNI sont saisis manuellement par l'utilisateur.
