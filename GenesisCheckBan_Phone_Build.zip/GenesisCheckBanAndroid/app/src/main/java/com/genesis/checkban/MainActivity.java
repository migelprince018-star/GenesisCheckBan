package com.genesis.checkban;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(12,12,14);
    private final int GOLD = Color.rgb(220,177,65);
    private final int WHITE = Color.WHITE;
    private SQLiteDatabase database;
    private LinearLayout root;
    private EditText phoneInput, noteInput;
    private Spinner statusSpinner;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        database = openOrCreateDatabase("genesis_checkban.db", MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS checks(phone TEXT PRIMARY KEY, status TEXT, note TEXT, checked_at TEXT)");
        showHome();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(8, 8, 8, 8);
        return t;
    }

    private void base(String subtitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(22, 26, 22, 18);
        root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        root.addView(text("༒  G E N E S I S  ༒", 24, GOLD, true));
        root.addView(text("CHECK BAN", 30, WHITE, true));
        root.addView(text("I AM ATOMIC  •  BY CID KAGENOU", 13, GOLD, true));
        root.addView(text(subtitle, 12, Color.LTGRAY, false));
        View line = new View(this);
        line.setBackgroundColor(GOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 1);
        lp.setMargins(0, 18, 0, 18); root.addView(line, lp);
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD));
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 7, 0, 7); root.addView(b, p);
        return b;
    }

    private EditText edit(String hint, int type) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setHint(hint); e.setTextColor(WHITE);
        e.setHintTextColor(Color.GRAY); e.setInputType(type);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD));
        root.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private void showHome() {
        base("REGISTRE LOCAL • SANS CONNEXION WHATSAPP");
        button("＋  Enregistrer un numéro", this::showAdd);
        button("⌕  Rechercher un numéro", this::showSearch);
        button("▤  Historique", this::showHistory);
        button("ℹ  À propos", () -> new android.app.AlertDialog.Builder(this)
            .setTitle("À propos")
            .setMessage("Cette application conserve les statuts que tu saisis toi-même. Elle ne peut pas vérifier automatiquement si WhatsApp a réellement banni un compte.")
            .setPositiveButton("OK", null).show());
        root.addView(text("OFF BY CID KAGENOU", 12, GOLD, true));
    }

    private String normalize(String s) {
        String v = s.trim().replaceAll("[\\s().-]", "");
        if (v.startsWith("00")) v = "+" + v.substring(2);
        if (!v.startsWith("+")) v = "+" + v;
        String digits = v.substring(1);
        if (!digits.matches("[0-9]{8,15}") || digits.startsWith("0")) return null;
        return v;
    }

    private void showAdd() {
        base("ENREGISTRER / METTRE À JOUR");
        phoneInput = edit("Numéro international, ex. +2376XXXXXXXX", InputType.TYPE_CLASS_PHONE);
        noteInput = edit("Note facultative", InputType.TYPE_CLASS_TEXT);
        statusSpinner = new Spinner(this);
        String[] choices = {"INCONNU / NON VÉRIFIÉ", "ACTIF (saisi manuellement)", "BANNI (saisi manuellement)"};
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, choices);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(a); root.addView(statusSpinner);
        button("ENREGISTRER", () -> {
            String phone = normalize(phoneInput.getText().toString());
            if (phone == null) { toast("Format invalide. Exemple : +237..."); return; }
            String[] vals = {"INCONNU", "ACTIF", "BANNI"};
            ContentValues cv = new ContentValues();
            cv.put("phone", phone); cv.put("status", vals[statusSpinner.getSelectedItemPosition()]);
            cv.put("note", noteInput.getText().toString());
            cv.put("checked_at", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date()));
            database.insertWithOnConflict("checks", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            toast("Enregistrement sauvegardé."); showHome();
        });
        button("RETOUR", this::showHome);
    }

    private void showSearch() {
        base("RECHERCHE DANS TA BASE LOCALE");
        EditText e = edit("Numéro à rechercher", InputType.TYPE_CLASS_PHONE);
        button("RECHERCHER", () -> {
            String phone = normalize(e.getText().toString());
            if (phone == null) { toast("Format invalide."); return; }
            Cursor c = database.rawQuery("SELECT status,note,checked_at FROM checks WHERE phone=?", new String[]{phone});
            if (c.moveToFirst()) {
                String result = phone + "\\nStatut enregistré : " + c.getString(0) +
                    "\\nNote : " + c.getString(1) + "\\nDate : " + c.getString(2) +
                    "\\n\\nCe statut est une donnée locale, pas une confirmation de WhatsApp.";
                new android.app.AlertDialog.Builder(this).setTitle("Résultat").setMessage(result).setPositiveButton("OK", null).show();
            } else toast("INCONNU — aucun enregistrement local.");
            c.close();
        });
        button("RETOUR", this::showHome);
    }

    private void showHistory() {
        base("HISTORIQUE");
        Cursor c = database.rawQuery("SELECT phone,status,note,checked_at FROM checks ORDER BY checked_at DESC", null);
        if (c.getCount() == 0) root.addView(text("Aucun enregistrement.", 15, WHITE, false));
        while (c.moveToNext()) {
            String item = c.getString(0) + "\\n" + c.getString(1) + "  •  " + c.getString(3) +
                (c.getString(2).isEmpty() ? "" : "\\n" + c.getString(2));
            root.addView(text(item, 14, WHITE, false));
            View line = new View(this); line.setBackgroundColor(GOLD);
            root.addView(line, new LinearLayout.LayoutParams(-1, 1));
        }
        c.close();
        button("RETOUR", this::showHome);
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
